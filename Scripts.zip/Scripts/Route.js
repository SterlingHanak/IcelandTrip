﻿var markers = [];
var windows = [];
var InfoWindow = "";

function initMap() {
    //Coordinates for each location.
    var middle = { lat: 64.963051, lng: -19.020835 };
    var reykjavik = { lat: 64.14746, lng: -21.93422 };
    var keflavik = { lat: 63.978841, lng: -22.632164 };
    var thrihnukagigur = { lat: 63.998462, lng: -21.698964 };
    var geysir = { lat: 64.310372, lng: -20.30236 };
    var gullfoss = { lat: 64.327072, lng: -20.119948 };
    var selfoss = { lat: 63.933461, lng: -21.001383 };
    var hengill = { lat: 64.183333, lng: -21.333333 };
    var seljalandsfoss = { lat: 63.615623, lng: -19.988569 };
    var skogafoss = { lat: 63.532052, lng: -19.51137 };
    var vik = { lat: 63.457482, lng: -19.385119 };
    var skaftafellsjokull = { lat: 64.065426, lng: -16.863473 };
    var hvannadalshnukur = { lat: 64.01466, lng: -16.674888 };
    var myvatn = { lat: 65.60386, lng: -16.996105 };
    var dimmuborgir = { lat: 65.595451, lng: -16.920262 };
    var dettifoss = { lat: 65.814666, lng: -16.384576 };
    var akureyri = { lat: 65.688492, lng: -18.126169 };
    var silfra = { lat: 64.255857, lng: -21.130362 };
    var eldhestar = { lat: 63.994938, lng: -21.197856 };
    var blueLagoon = { lat: 63.879124, lng: -22.445573 };
    var jokulsarlon = { lat: 64.078446, lng: -16.230554 };

    //Function to load the map, centered at the middle of Iceland.
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 7,
        center: middle,
        // mapTypeId: google.maps.MapTypeId.TERRAIN,
        styles: [
  {
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#1d2c4d"
      }
    ]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#8ec3b9"
      }
    ]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#1a3646"
      }
    ]
  },
  {
    "featureType": "administrative.country",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#4b6878"
      }
    ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#64779e"
      }
    ]
  },
  {
    "featureType": "administrative.province",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#4b6878"
      }
    ]
  },
  {
    "featureType": "landscape.man_made",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#334e87"
      }
    ]
  },
  {
    "featureType": "landscape.natural",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#023e58"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#283d6a"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#6f9ba5"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#1d2c4d"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#023e58"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#3C7680"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#304a7d"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#98a5be"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#1d2c4d"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#2c6675"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#255763"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#b0d5ce"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#023e58"
      }
    ]
  },
  {
    "featureType": "transit",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#98a5be"
      }
    ]
  },
  {
    "featureType": "transit",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#1d2c4d"
      }
    ]
  },
  {
    "featureType": "transit.line",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#283d6a"
      }
    ]
  },
  {
    "featureType": "transit.station",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#3a4762"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#0e1626"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#4e6d70"
      }
    ]
  }
]
    });

InfoWindow = new google.maps.InfoWindow();

 $.getJSON("Scripts/Iceland.json", function(json){
     for ( var i = 0; i < json.length; i++) { 
          var location = { lat: json[i].latitude, lng: json[i].longitude};
          var marker = new google.maps.Marker({ position: location, map: map, title: json[i].title, animation: google.maps.Animation.DROP, id:i});

          var info = json[i].content.container + json[i].content.header + json[i].content.description + json[i].content.image + json[i].content.end;

           marker.addListener('click', function() {
            console.log(marker.id);
               InfoWindow.setContent(info);
               InfoWindow.open(map, marker);
             });

           markers.push(marker);
           console.log(marker);
     }  
 });



    //Markers for each location.
    // var marker1 = new google.maps.Marker({ position: reykjavik, map: map, title: 'City of Reykjavík', animation: google.maps.Animation.DROP });
    // var marker2 = new google.maps.Marker({ position: keflavik, map: map, title: 'Keflavík Airport', animation: google.maps.Animation.DROP });
    // var marker3 = new google.maps.Marker({ position: thrihnukagigur, map: map, title: 'Thrihnukagigur Volcano', animation: google.maps.Animation.DROP });
    // var marker4 = new google.maps.Marker({ position: geysir, map: map, title: 'Geysir', animation: google.maps.Animation.DROP });
    // var marker5 = new google.maps.Marker({ position: gullfoss, map: map, title: 'Gullfoss Falls', animation: google.maps.Animation.DROP });
    // var marker6 = new google.maps.Marker({ position: selfoss, map: map, title: 'Selfoss', animation: google.maps.Animation.DROP });
    // var marker7 = new google.maps.Marker({ position: hengill, map: map, title: 'Hengill', animation: google.maps.Animation.DROP });
    // var marker8 = new google.maps.Marker({ position: seljalandsfoss, map: map, title: 'Seljalandsfoss Waterfall', animation: google.maps.Animation.DROP });
    // var marker9 = new google.maps.Marker({ position: skogafoss, map: map, title: 'Skógafoss Waterfall', animation: google.maps.Animation.DROP });
    // var marker10 = new google.maps.Marker({ position: vik, map: map, title: 'Black Sand Beach', animation: google.maps.Animation.DROP });
    // var marker11 = new google.maps.Marker({ position: skaftafellsjokull, map: map, title: 'Skaftafellsjökull Camp Site', animation: google.maps.Animation.DROP });
    // var marker12 = new google.maps.Marker({ position: hvannadalshnukur, map: map, title: 'Hvannadalshnúkur Mountain', animation: google.maps.Animation.DROP });
    // var marker13 = new google.maps.Marker({ position: myvatn, map: map, title: 'Lake Mývatn Camp Site', animation: google.maps.Animation.DROP });
    // var marker14 = new google.maps.Marker({ position: dimmuborgir, map: map, title: 'Dimmuborgir Rock Formation', animation: google.maps.Animation.DROP });
    // var marker15 = new google.maps.Marker({ position: dettifoss, map: map, title: 'Dettifoss Waterfall', animation: google.maps.Animation.DROP });
    // var marker16 = new google.maps.Marker({ position: akureyri, map: map, title: 'City of Akureyri', animation: google.maps.Animation.DROP });
    // var marker17 = new google.maps.Marker({ position: silfra, map: map, title: 'Silfra Fissure', animation: google.maps.Animation.DROP });
    // var marker18 = new google.maps.Marker({ position: eldhestar, map: map, title: 'Eldhestar Beach', animation: google.maps.Animation.DROP });
    // var marker19 = new google.maps.Marker({ position: blueLagoon, map: map, title: 'Blue Lagoon Hot Spring', animation: google.maps.Animation.DROP });
    // var marker20 = new google.maps.Marker({ position: jokulsarlon, map: map, title: 'Glacier Lagoon', animation: google.maps.Animation.DROP });

    //Content Strings to fill the info window for each location.
    var content1 = '<div id="content">' + '<h1 id="infoHead">Reykjavík</h1>' + '<p>The capital city of Iceland, we stayed here both at the beginning and end of the trip.  We enjoyed some fine Icelandic cuisine here at several great restaurants, met some nice locals, shopped, and enjoyed the night life by attending many different bars.  Including a bar themed after my favorite movie: The Big Lebowski.</p>' + '<img src="Content/IcelandPics/ReyChurch.jpg" class="infoImage" />' + '</div>';
    var content2 = '<div id="content">' + '<h1 id="infoHead">Keflavík</h1>' + '<p>Here is where we officially arrived in Iceland, as it was the main airport for the country.  It was an absolutely beautiful airport, which was fortunate because we spent a lot of time here due to flight delays.</p>';
    var content3 = '<div id="content">' + '<h1 id="infoHead">Thrihnukagigur Volcano</h1>' + '<p>Here is where we participated in our first activity of the trip, and it was one offered only in Iceland.  Thrihnukagigur Volcano has been long dormant, so it was rigged to allow visitors to travel down inside of it.  You heard correctly, we went inside of a volcano!</p>' + '<img src="Content/IcelandPics/Volcano.jpg" class="infoImage" />' + '</div>';
    var content4 = '<div id="content">' + '<h1 id="infoHead">Geysir</h1>' + '<p>The Land of Fire and Ice had many geysirs and waterfalls scattered across its landscape.  This was the first of many that we witnessed.</p>' + '<img src="Content/IcelandPics/Geysir.jpg" class="infoImage" />' + '</div>';
    var content5 = '<div id="content">' + '<h1 id="infoHead">Gullfoss Falls</h1>' + '<p>One of the larger set of waterfalls in the country, it was only thwarted later in the trip by the enormous Dettifoss.  We hung out here for quite a bit, because it was also where we were picked up to go snow mobiling.</p>' + '<img src="Content/IcelandPics/Waterfall1.jpg" class="infoImage" />' + '</div>';
    var content6 = '<div id="content">' + '<h1 id="infoHead">Selfoss</h1>';
    var content7 = '<div id="content">' + '<h1 id="infoHead">Hengill</h1>' + '<p>Possibly the greatest event of the entire trip, Hengill was a large mountain range where two wonderful guides took us on an all-day mountain biking adventure.  We ended the incredible experience by bathing in what would be our first set of natural Icelandic hot springs.</p>' + '<img src="Content/IcelandPics/Bike.jpg" class="infoImage" />' + '</div>';
    var content8 = '<div id="content">' + '<h1 id="infoHead">Seljalandfoss Waterfall</h1>' + '<p>Different from some of the larger waterfalls in the country, this one was more traditional along a mountainside.  We enjoyed dinner here at a nearby cafe before traveling just down the road to camp along the black sand beach.</p>' + '<img src="Content/IcelandPics/Waterfall2.jpg" class="infoImage" />' + '</div>';
    var content9 = '<div id="content">' + '<h1 id="infoHead">Skógafoss Waterfall</h1>';
    var content10 = '<div id="content">' + '<h1 id="infoHead">Black Sand Beach</h1>' + '<p>Another unanimous favorite for the group, Iceland contained one of the world\'s only black sand beaches.  Naturally, we set up camp right then and there so we can enjoy its splendor all throughout the night, no matter how windy it might have been.  We even got to see a wild seal in the ocean!</p>' + '<img src="Content/IcelandPics/Beach.jpg" class="infoImage" />' + '</div>';
    var content11 = '<div id="content">' + '<h1 id="infoHead">Skaftafellsjökull Camp Site</h1>' + '<p>Unfortunately one of the most disappointing legs of the trip happened here.  While the camp site was absolutely beautiful at the base of the mountain, the lack of wifi caused us to miss important instructions emailed to us by what would have been our mountain guides.  While we missed out on what possibly could have been the greatest part of the trip in an expidition atop Iceland\'s largest mountain, we still got to enjoy another night of camping in the brisk wilderness.</p>';
    var content12 = '<div id="content">' + '<h1 id="infoHead">Hvannadalshnúkur Mountain</h1>' + '<p>While we didn\'t actually get to climb this particular mountain as intended, we later made up for it by climbing to the peak of our own psuedo-Hvannadalshnúkur that we found along the road.</p>';
    var content13 = '<div id="content">' + '<h1 id="infoHead">Lake Mývatn Camp Site</h1>' + '<p>When we arrived, Lake Mývatn looked absolutely stunning and we quickly set up camp to enjoy some time along the lake.  That enjoyment quickly faded, however, as we later learned that Lake Mývatn loosely translated to "Bug Lake".</p>' + '<img src="Content/IcelandPics/Myvatn.jpg" class="infoImage" />' + '</div>';
    var content14 = '<div id="content">' + '<h1 id="infoHead">DimmuBorgir Rock Formation</h1>' + '<p>I was particularly excited to see this location, as Dimmu Borgir was the name of a Norwegian Black Metal band that I adored, and this was where they got their name.  Meaning "Dark Cities", Dimmuborgir was as eerie to look at as it was interesting.  We also hiked a short trail through and around the rock formation.</p>' + '<img src="Content/IcelandPics/DimmuBorgir.jpg" class="infoImage" />' + '</div>';
    var content15 = '<div id="content">' + '<h1 id="infoHead">Dettifoss Waterfall</h1>' + '<p>This had to be the largest waterfall in the country, and it delivered.  Reminiscent of Niagra Falls, Dettifoss was also famous, for many movies and tv shows where filmed here, including more recently Prometheus.</p>' + '<img src="Content/IcelandPics/BigWaterfall.jpg" class="infoImage" />' + '</div>';
    var content16 = '<div id="content">' + '<h1 id="infoHead">Akureyri</h1>' + '<p>One of the biggest surprises of the trip (for spending the night here wasn\'t initially planned), Akureyri was the second largest city in the country.  It didn\'t feel that large though, as it gave a more secluded and cozy vibe.  We stayed in a beautiful apartment and spent the night at some local bars, including "Backpackers", where we enjoyed part of the evening with some Icelandic girls who were celebrating their graduation from school.</p>' + '<img src="Content/IcelandPics/Akureyri.jpg" class="infoImage" />' + '</div>';
    var content17 = '<div id="content">' + '<h1 id="infoHead">Silfra Fissure</h1>' + '<p>Another "Iceland Only" experience, we got to snorkel in between two tectonic plates!  Though the water was absolutely freezing, the experience itself was once in a lifetime.</p>';
    var content18 = '<div id="content">' + '<h1 id="infoHead">Eldhestar Beach</h1>' + '<p>It was here that we embarked on our last major activity of the trip: horseback riding.  Icelandic horses where smaller and had longer hair than the horses we were acustomed to, and the journey spanned far beyond just the beach.  The scenary was gorgeous, though I felt like I wouldn\'t be able to walk for a week at the conclusion of the ride.</p>' + '<img src="Content/IcelandPics/Horses.jpg" class="infoImage" />' + '</div>';
    var content19 = '<div id="content">' + '<h1 id="infoHead">Blue Lagoon</h1>' + '<p>Just before we left for America, we stopped at arguably the country\'s most famous destination: the Blue Lagoon hot spring.  Words cannot describe the feelings we felt here and pictures cannot do it justice.  If you ever travel to Iceland, be sure you stop here.</p>' + '<img src="Content/IcelandPics/BlueLagoon.jpg" class="infoImage" />' + '</div>';
    var content20 = '<div id="content">' + '<h1 id="infoHead">Jökulsárlón Glacier</h1>' + '<p>This location perfectly sumarized my perception of Iceland before I had a chance to visit.  The glacier lagoon was mezmerizingly beautiful, with a mountain range in the distance serving as the backdrop.  We even got to ride a boat through the lagoon and see the iceburgs up close, and we each got to taste a piece of ice that was over 1,000 years old.</p>' + '<img src="Content/IcelandPics/GlacierLagoon.jpg" class="infoImage" />' + '</div>';

    // //Functions to open the specific info window for each location.
    // var infowindow1 = new google.maps.InfoWindow({ content: content1 });
    // marker1.addListener('click', function () {
    //     infowindow1.open(map, marker1);
    // });
    // var infowindow2 = new google.maps.InfoWindow({ content: content2 });
    // marker2.addListener('click', function () {
    //     infowindow2.open(map, marker2);
    // });
    // var infowindow3 = new google.maps.InfoWindow({ content: content3 });
    // marker3.addListener('click', function () {
    //     infowindow3.open(map, marker3);
    // });
    // var infowindow4 = new google.maps.InfoWindow({ content: content4 });
    // marker4.addListener('click', function () {
    //     infowindow4.open(map, marker4);
    // });
    // var infowindow5 = new google.maps.InfoWindow({ content: content5 });
    // marker5.addListener('click', function () {
    //     infowindow5.open(map, marker5);
    // });
    // var infowindow6 = new google.maps.InfoWindow({ content: content6 });
    // marker6.addListener('click', function () {
    //     infowindow6.open(map, marker6);
    // });
    // var infowindow7 = new google.maps.InfoWindow({ content: content7 });
    // marker7.addListener('click', function () {
    //     infowindow7.open(map, marker7);
    // });
    // var infowindow8 = new google.maps.InfoWindow({ content: content8 });
    // marker8.addListener('click', function () {
    //     infowindow8.open(map, marker8);
    // });
    // var infowindow9 = new google.maps.InfoWindow({ content: content9 });
    // marker9.addListener('click', function () {
    //     infowindow9.open(map, marker9);
    // });
    // var infowindow10 = new google.maps.InfoWindow({ content: content10 });
    // marker10.addListener('click', function () {
    //     infowindow10.open(map, marker10);
    // });
    // var infowindow11 = new google.maps.InfoWindow({ content: content11 });
    // marker11.addListener('click', function () {
    //     infowindow11.open(map, marker11);
    // });
    // var infowindow12 = new google.maps.InfoWindow({ content: content12 });
    // marker12.addListener('click', function () {
    //     infowindow12.open(map, marker12);
    // });
    // var infowindow13 = new google.maps.InfoWindow({ content: content13 });
    // marker13.addListener('click', function () {
    //     infowindow13.open(map, marker13);
    // });
    // var infowindow14 = new google.maps.InfoWindow({ content: content14 });
    // marker14.addListener('click', function () {
    //     infowindow14.open(map, marker14);
    // });
    // var infowindow15 = new google.maps.InfoWindow({ content: content15 });
    // marker15.addListener('click', function () {
    //     infowindow15.open(map, marker15);
    // });
    // var infowindow16 = new google.maps.InfoWindow({ content: content16 });
    // marker16.addListener('click', function () {
    //     infowindow16.open(map, marker16);
    // });
    // var infowindow17 = new google.maps.InfoWindow({ content: content17 });
    // marker17.addListener('click', function () {
    //     infowindow17.open(map, marker17);
    // });
    // var infowindow18 = new google.maps.InfoWindow({ content: content18 });
    // marker18.addListener('click', function () {
    //     infowindow18.open(map, marker18);
    // });
    // var infowindow19 = new google.maps.InfoWindow({ content: content19 });
    // marker19.addListener('click', function () {
    //     infowindow19.open(map, marker19);
    // });
    // var infowindow20 = new google.maps.InfoWindow({ content: content20 });
    // marker20.addListener('click', function () {
    //     infowindow20.open(map, marker20);
    // });
}